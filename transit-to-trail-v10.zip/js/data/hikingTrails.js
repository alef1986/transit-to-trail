// Pre-packaged static hiking trails sample (expandable anytime via `python scripts/fetch_trails_data.py`)
// Source: OpenStreetMap (route=hiking, ODbL)
export const HIKING_TRAILS = [
  {
    id: 2451001,
    name: "Szlak Doliny Bobru (żółty PTTK)",
    color: "#eab308",
    lenKm: 18.4,
    bbox: [50.912, 15.618, 50.975, 15.665],
    segments: [
      [[50.9672, 15.6365], [50.9615, 15.6320], [50.9530, 15.6260], [50.9425, 15.6285], [50.9310, 15.6370], [50.9210, 15.6420], [50.9163, 15.6448]]
    ]
  },
  {
    id: 2451002,
    name: "Szlak Zamków Piastowskich (zielony PTTK)",
    color: "#16a34a",
    lenKm: 24.6,
    bbox: [50.895, 15.605, 51.018, 15.680],
    segments: [
      [[51.0155, 15.6708], [50.9960, 15.6520], [50.9740, 15.6410], [50.9500, 15.6340], [50.9260, 15.6220], [50.9163, 15.6448]]
    ]
  },
  {
    id: 2451003,
    name: "Główny Szlak Sudecki — odcinek karkonoski (czerwony)",
    color: "#dc2626",
    lenKm: 29.0,
    bbox: [50.805, 15.430, 50.855, 15.760],
    segments: [
      [[50.8151, 15.4307], [50.8220, 15.4850], [50.8304, 15.5245], [50.8380, 15.5750], [50.8450, 15.6250], [50.8511, 15.6024]]
    ]
  },
  {
    id: 2451004,
    name: "Hřebenovka / Droga Przyjaźni (červená KČT / PL)",
    color: "#dc2626",
    lenKm: 21.2,
    bbox: [50.764, 15.367, 50.820, 15.440],
    segments: [
      [[50.8151, 15.4307], [50.8020, 15.4120], [50.7851, 15.4055], [50.7740, 15.3880], [50.7642, 15.3679]]
    ]
  },
  {
    id: 2451005,
    name: "Szlak Rudawski (niebieski PTTK)",
    color: "#2563eb",
    lenKm: 15.8,
    bbox: [50.845, 15.915, 50.890, 16.035],
    segments: [
      [[50.8819, 15.9221], [50.8740, 15.9500], [50.8650, 15.9780], [50.8550, 16.0020], [50.8471, 16.0268]]
    ]
  },
  {
    id: 2451006,
    name: "Malerweg Elbsandsteingebirge (rot)",
    color: "#dc2626",
    lenKm: 19.5,
    bbox: [50.885, 14.135, 50.960, 14.235],
    segments: [
      [[50.9189, 14.1398], [50.9080, 14.1650], [50.8980, 14.1950], [50.8884, 14.2312]]
    ]
  }
];
